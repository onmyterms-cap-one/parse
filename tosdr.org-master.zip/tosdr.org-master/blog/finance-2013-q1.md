# finances 2013 Q1:

# Start
(from https://github.com/tosdr/tosdr.org/blob/master/blog/finance-2012-attachment-finance.md )

* kept safe by Hugo: 11622.46 EUR
* kept safe by Michiel: 6524.52 EUR

# Money out

* compensation Hugo: 800
    * (H) project management, 4 weeks * 5 hours * 10 euros: 200 (Sat 8 Dec - Fri 4 Jan)
    * (H) project management, 4 weeks * 5 hours * 10 euros: 200 (Sat 5 Jan - Fri 1 Feb)
    * (H) project management, 4 weeks * 5 hours * 10 euros: 200 (Sat 2 Feb - Fri 1 Mar)
    * (H) project management, 4 weeks * 5 hours * 10 euros: 200 (Sat 2 Mar - Fri 29 Mar)

* compensation Jimm: 800
    * (M) 30 hours (up to 90) * 10 euros: 300 (28 Jan)
    * (M) 10 hours (up to 100) * 10 euros: 100 (1 Feb)
    * (M) 10 hours (up to 110) * 10 euros: 100 (18 Feb)
    * (M) 10 hours (up to 120) * 10 euros: 100 (26 Feb)
    * (M) 20 hours (up to 140) * 10 euros: 200 (5 Mar)


* compensation Ian: 300
    * (M) curating ML threads to data points, 15 hours (up to 40) * 10 euros: 150 (26 Feb)
    * (M) curating ML threads to data points, 15 hours (up to 55) * 10 euros: 150 (17 Mar)


* paypal: 11
    * (M) fee: 11


* perks: 247.18 + 29.60 + 156 + 300 + 18 + 4 + 355 + 19.12 + 5.76 = 1134.66
    * (M) StickerMule: 247.18 EUR
    * (M) Vietnamese import tax for stickers: 800 kDong =(rate: 0.037) 29.60 EUR
    * (M) T-shirts: 120x5.20 = 624 Ringgit =(rate: 0.25) 156 EUR
    * (M) textile printing: 120x10 = 1200 Ringgit =(rate: 0.25) 300 EUR
    * (M) 120 big envelopes: 72 Ringgit =(rate: 0.25) 18 EUR
    * (M) 105 small envelopes: 16 Ringgit =(rate: 0.25) 4 EUR
    * (M) stamps from Kuala Lumpur: 1420 Ringgit =(rate: 0.25) 355 EUR
    * (M) stamps from Kota Kinabalu: 76.50 Ringgit =(rate: 0.25) 19.12 EUR
    * (M) stamps from Shanghai: 48 RMB =(rate: 0.12) 5.76 EUR

  
* TOSBack crawler hosting: 17.19 + 17.19 +17.19 = 51.57
    * (M) 1 Jan rackspace invoice: 22.32 USD =(rate: 0.77) 17.19 EUR
    * (M) 1 Feb rackspace invoice: 22.32 USD =(rate: 0.77) 17.19 EUR
    * (M) 1 Mar rackspace invoice: 22.32 USD =(rate: 0.77) 17.19 EUR

* domain: 11.41
    * (H) transfer tosdr.org to gandi (25/03/2013): 11.41 EUR

* IRC Cloud: 27.69
    * (H) monthly subscription for October: 5 USD = 3.96 EUR
    * (H) monthly subscription for November: 5 USD = 4.03 EUR
    * (H) monthly subscription for December: 5 USD = 3.99 EUR
    * (H) monthly subscription for January: 5 USD = 3.96 EUR
    * (H) monthly subscription for February: 5 USD = 3.81 EUR
    * (H) monthly subscription for March: 5 USD = 3.97 EUR
    * (H) monthly subscription for April: 5 USD = 3.97 EUR

* conference costs: 171.03
    * (H) Flight to Gotenburg for FSCONS: 139.03 EUR
    * (H) Shuttle Paris-Beauvais Airport: 32 EUR

# Finish: 10612.33 + 4227.29  = 14839.62 EUR

* kept safe by Hugo: 11622.46 - 800 -11.41 - 27.69 - 171.03 = 10612.33 EUR
* kept safe by Michiel: 6524.52 - 800 - 300 - 11 - 1134.66 - 51.57 =  4227.29 EUR

