# finances 2014 Q1:

# Start: 9362.33 - 171.71 = 9190.62 EUR 
(from https://github.com/tosdr/tosdr.org/blob/master/blog/finance-2013-q4.md )

* kept safe by Hugo: 9362.33 EUR
* kept safe by Michiel:-171.71 EUR

# Money out

* operations: 15.48
    * (M) tosback server at serverdragon - one month: $6.99=5.16 EUR (5 Jan)
    * (M) tosback server at serverdragon - one month: $6.99=5.16 EUR (5 Feb)
    * (M) tosback server at serverdragon - one month: $6.99=5.16 EUR (5 Mar)

# Finish: 9362.33 - 187.19  = 9175.14 EUR

* kept safe by Hugo: 9362.33 = 9362.33 EUR
* kept safe by Michiel: -171.71 - 15.48 = -187.19 EUR
