# finances 2014 Q2:

# Start: 9362.33 - 187.19  = 9175.14 EUR 
(from https://github.com/tosdr/tosdr.org/blob/master/blog/finance-2014-q1.md )

* kept safe by Hugo: 9362.33 EUR
* kept safe by Michiel: -187.19 EUR

# Money out

* compensation Jimm: 300 EUR
    * (H) working on version 3 and maintaining version 2 of tosback.org - 30 hours (up to 280) * 10 euros: 300 EUR (on or after 12 Jun?)

* compensation Michiel: 50 EUR
    * (M) working on importing data points directly from Google Groups IMAP - 5 hours (up to 20) * 10 euros: 50 EUR (25 Jun)

* paypal: 3 EUR
    * (H) fee: 3 EUR (please confirm?)

* operations: 31.60 EUR
    * (M) tosback server at serverdragon - one month: $6.99=5.16 EUR (5 Apr)
    * (M) tosback server at serverdragon - one month: $6.99=5.16 EUR (5 May)
    * (M) tosback server at serverdragon - one month: $6.99=5.16 EUR (5 Jun)
    * (H) tosdr.org DNR renewal 16.12 EUR (30 Jun)

# Finish: 9043.21 - 237.19  = 8806.02 EUR

* kept safe by Hugo: 9362.33 - 300 - 3 - 16.12 = 9043.21 EUR
* kept safe by Michiel: -187.19 - 15.48 - 50 = -237.19 EUR
