# finances 2013 Q2:

# Start
(from https://github.com/tosdr/tosdr.org/blob/master/blog/finance-2013-q1.md )

* kept safe by Hugo: 10612.33 EUR
* kept safe by Michiel: 4227.29 EUR

# Money out

* compensation Hugo: 1250
    * (H) project management, 5 weeks * 5 hours * 10 euros: 250 (Sat 30 Mar - Fri 3 May)
    * (H) full-time May: 500
    * (H) full-time June: 500

* compensation Suzanne: 1000
    * (M) full-time May: 500
    * (M) full-time June: 500

* compensation Jimm: 700
    * (M) 10 hours (up to 150) * 10 euros: 100 (6 May)
    * (M) 10 hours (up to 160) * 10 euros: 100 (3 Jun)
    * (M) 10 hours (up to 170) * 10 euros: 100 (18 Jun)
    * (M) 30 hours (up to 200) * 10 euros: 300 (25 Jun)
    * (M) 10 hours (up to 210) * 10 euros: 100 (10 Jul)

* compensation Ian: 750
    * (M) curating ML threads to data points, 15 hours (up to 60) * 10 euros: 150 (26 Apr)
    * (M) curating ML threads to data points, 15 hours (up to 75) * 10 euros: 150 (6 May)
    * (M) curating ML threads to data points, 15 hours (up to 90) * 10 euros: 150 (4 Jun)
    * (M) curating ML threads to data points, 15 hours (up to 105) * 10 euros: 150 (17 Jun)
    * (M) curating ML threads to data points, 15 hours (up to 120) * 10 euros: 150 (10 Jul)

* compensation Adrian: 300
    * (M) improving the build script,          10 hours (up to 10) * 10 euros: 100 (31 Jul)
    * (M) porting html templating to Mustache, 10 hours (up to 20) * 10 euros: 100 (31 Jul)
    * (M) preparing for topic cases,           10 hours (up to 30) * 10 euros: 100 (31 Jul)

* paypal: 14.50
    * (M) fee: 14.50

* TOSBack crawler hosting: 17.19 + 17.19 + 17.19 = 51.57
    * (M) 1 Apr rackspace invoice: 22.32 USD =(rate: 0.77) 17.19 EUR
    * (M) 1 May rackspace invoice: 22.32 USD =(rate: 0.77) 17.19 EUR
    * (M) 1 Jun rackspace invoice: 22.32 USD =(rate: 0.77) 17.19 EUR

# Finish: 9362.33 + 1411.22  = 10773.55 EUR

* kept safe by Hugo: 10612.33 - 1250 = 9362.33 EUR
* kept safe by Michiel: 4227.29 - 1000 - 700 - 750 - 300 - 14.50 - 51.57 =  1411.22 EUR

