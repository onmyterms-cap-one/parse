# finances 2014 Q3:

# Start: 9043.21 - 237.19  = 8806.02 EUR
(from https://github.com/tosdr/tosdr.org/blob/master/blog/finance-2014-q2.md )

* kept safe by Hugo: 9043.21 EUR
* kept safe by Michiel: -237.19 EUR

# Money out

* operations: 15.48 EUR
    * (M) tosback server at serverdragon - one month: $6.99=5.16 EUR (5 Jul)
    * (M) tosback server at serverdragon - one month: $6.99=5.16 EUR (5 Aug)
    * (M) tosback server at serverdragon - one month: $6.99=5.16 EUR (5 Sep)

# Finish: 9043.21 - 252.67  = 8790.54 EUR

* kept safe by Hugo: 9043.21 EUR
* kept safe by Michiel: -237.19 - 15.48 = -252.67 EUR
