MONEY IN: 1654.09+8108.12+9990+1500+98 = 21350.21 EUR
=======================
 
 * (M) donation from the Unhosted project: 1500 (internship Hugo)
 * (H) Flattr: 98 (withdrawn; there is about 60 more euros in there waiting)

------- Indiegogo: -------

 * (H) Indiegogo campaign part I: 1654.09
 * (M) Indiegogo campaign part II: 8108.12
 * (-) IGG fee: 429.28
 * (-) paypal fee: 544.51
 * (H) Gruender garage matching funds: 9990
 * (-) bank fee: 10

------- Indiegogo total: 1654.09+8108.12+429.28+544.51+10 = 20736.00 -------


TRANSFERS: M->H: 1822.28
=======================

 * M -> H (2012/07/02): 556
 * M -> H (2012/08/02): 520
 * M -> H (2012/08/31): 750
 * M -> H (2012/08/24): 5
 * H -> M (2012/09/09): 8.72

 * Total donations via Hugo: 1654.09+9990+98+1822.28 = 13564.37
 * Total donations via Michiel: 8108.12+1500-1822.28 = 7785.84

 Sanity check: 13564.37+7785.84 = 21350.21

MONEY OUT: 1900+600+250+8.5+49.27+34.57+84+276.89=3203.23
=======================

 * compensation Hugo: 1900
    * (H) internship, 3 months * 500 euros: 1500 (1 June - 31 Aug)
    * (H) project management, 4 weeks * 5 hours * 10 euros: 200 (Sat 13 Oct - Fri 9 Nov)
    * (H) project management, 4 weeks * 5 hours * 10 euros: 200 (Sat 10 Nov - Fri 7 Dec)
 * compensation Jimm: 600
    * (M) taking over tosback project from EFF, 10 hours * 10 euros: 100 (15 Dec)
    * (M) taking over tosback project from EFF, 20 hours * 10 euros: 200 (24 Nov)
    * (M) taking over tosback project from EFF, 10 hours * 10 euros: 100 (13 Nov)
    * (M) taking over tosback project from EFF, 10 hours * 10 euros: 100 (30 Oct)
    * (M) taking over tosback project from EFF, 10 hours * 10 euros: 100 (10 Oct)
 * compensation Ian: 250
    * (M) curating ML threads to data points, 15 hours * 10 euros: 150 (15 Dec)
    * (M) curating ML threads to data points, 10 hours * 10 euros: 100 (30 Oct)
 * paypal: 8.50
    * (M) fee: 8.50
 * domain name registration: 49.27
    * (M) tos-dr.info: 2.17 USD = 1.71
    * (M) tosdr.org: 7.17 USD = 5.65
    * (H) didnotread.org: 15
    * (H) cgupas.lu: 26.91
 * hosting: 34.57
    * (M) tosback server: 21.66 USD = 17.07 (1 Dec)
    * (M) tosback server: 22.21 USD = 17.50 (1 Nov)
 * office space: 84
    * (H) co-up.de Hugo: 20 (June)
    * (H) co-up.de Hugo: 44 (July)
    * (H) co-up.de Hugo: 20 (August)
 * Hugo attending Unhost'12: 276.89
    * (H) flight: 183.59
    * (M) stay: 93.30

MONEY HAVE: 11354.87 + 6792.11 = 18146.98
=======================

 * kept safe by Hugo: 13564.37 - 1500 - 200 - 200 - 15 - 26.91 - 20 - 44 - 20 - 183.59 = 11354.87
 * kept safe by Michiel: 7785.84 - 100 - 200 - 100 - 100 - 100 - 150 - 100 - 8.50
  - 1.71 - 5.65 - 17.07 - 17.50 - 93.30 = 6792.11

Sanity check: 21350.21 (IN) - 3203.23 (OUT) = 18146.98 (HAVE)
