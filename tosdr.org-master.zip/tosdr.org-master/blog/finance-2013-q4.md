# finances 2013 Q4:

# Start
(from https://github.com/tosdr/tosdr.org/blob/master/blog/finance-2013-q3.md )

* kept safe by Hugo: 9362.33 EUR
* kept safe by Michiel:183.77 EUR

# Money out

* compensation Michiel: 150
    * (M) adopting https://github.com/tosdr/tosdr.org/wiki/Specification:-points - 3 hours (up to 8) * 10 euros: 30 (1 Oct)
    * (M) introducing https://github.com/tosdr/tosdr.org/wiki/cases - 2 hours (up to 10) * 10 euros: 20 (3 Oct)
    * (M) assigning cases to several topics- 2 hours (up to 12) * 10 euros: 20 (4 Oct)
    * (M) assigning cases to remaining topics- 2 hours (up to 14) * 10 euros: 20 (6 Oct)
    * (M) scripts/checkcases.js - 1 hour (up to 15) * 10 euros: 20 (8 Oct)

* compensation Vincent: 190
    * (M) comments form, step 1 - 2, 5 hours (up to 5) * 10 euros: 50 (22 Oct)
    * (M) comments form, step 3 - 4, 7 hours (up to 12) * 10 euros: 70 (29 Oct)
    * (M) pendingpoints form, 7 hours (up to 19) * 10 euros: 70 (28 Nov)

* operations: 15.48
    * (M) tosback server at serverdragon - one month: $6.99=5.16 EUR (5 Oct)
    * (M) tosback server at serverdragon - one month: $6.99=5.16 EUR (5 Nov)
    * (M) tosback server at serverdragon - one month: $6.99=5.16 EUR (5 Dec)

# Finish: 9362.33 - 171.71  = 9190.62 EUR

* kept safe by Hugo: 9362.33 = 9362.33 EUR
* kept safe by Michiel: 183.77 - 150 - 190 - 15.48 = -171.71 EUR
