echo "
Reputation.com service cannot be canceled online"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c751a611078a57e7# | grep Location
echo "
PATH makes it very hard deleting your account by &quot;hiding&quot; this option"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/04156ee49271c4f5# | grep Location
echo "
Fwd: The new &quot;Who Has Your Back?&quot; report is out!"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2f630fa0a868fec8# | grep Location
echo "
Google ranks class C?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f04e404bf321c1f8# | grep Location
echo "
Google can share your information with others"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/419811f1f6915835# | grep Location
echo "
Google may stop providing a service to you at any time"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8e2eee01a5d74cde# | grep Location
echo "
Google may discontinue services and give you notice to get your data out"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3c3e595b382fd912# | grep Location
echo "
Google&#39;s license to your content does not end when you stop using the service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/db1be365fd6681dd# | grep Location
echo "
Google can use your content in all existing and future services"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/567ec77b9e1d9d52# | grep Location
echo "
Adding ~90 new entries to services/?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6184cc2635c5f1c1# | grep Location
echo "
JAGEX [bad] You must pay a fee to have your personal information deleted"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7bb28d5ef539ac37# | grep Location
echo "
JAGEX [bad] You must pay a fee to request a copy of your personal information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/672f9d157c9cf5da# | grep Location
echo "
JAGEX [note] Parents may request the account information of their children under 18 by faxing or mai"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5598fd44517b00a5# | grep Location
echo "
JAGEX [note] Your personal information may be shared with third parties on an opt-in basis"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/12e932e831e8c7da# | grep Location
echo "
Jagex uses third-party cookies for advertising targeting"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0b7674db82a6d11f# | grep Location
echo "
JAGEX [note] Your Personal Information may be stored anywhere in the world and may affect your priva"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5b15d5ef0c8dd254# | grep Location
echo "
JAGEX [good] Newsletters are opt-in, although account notices will still be sent"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/96fc7b676ac5e624# | grep Location
echo "
JAGEX [bad] Information about you will be used to target advertising"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/14585e6b4f4960ad# | grep Location
echo "
JAGEX [info] Aggregate information is provided to partners"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4d4ac16153a819d4# | grep Location
echo "
JAGEX [bad] Error reports from client software are sent automatically"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/67a159ddcbbdd191# | grep Location
echo "
JAGEX [bad] Collects information about your location, hardware and software"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/798eef1616cf3ac1# | grep Location
echo "
JAGEX [bad] Does not consider an IP address or browser tag Personal Identifiable information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/cbf075278965b920# | grep Location
echo "
JAGEX - Choice of court is England"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/becc42d50de8231b# | grep Location
echo "
JAGEX [bad] Jagex may transfer the agreement and your information to another party at any time"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/abfb95e5b940f9c2# | grep Location
echo "
JAGEX - You are liable of any losses you incur to Jagex"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/35e6714d6c490e76# | grep Location
echo "
JAGEX [info] You may request a refund, although there is no assurance the request will be approved"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/de71a05e6db22684# | grep Location
echo "
JAGEX [bad] Access to digital currency or game items can be revoked at any time"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/29564e7f307877b7# | grep Location
echo "
JAGEX [bad] Restrictions on use of virtual currency may change at any time"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/24d015088b930252# | grep Location
echo "
JAGEX [bad] You may not sell or transfer virtual currency to anyone else."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/601a75214177b502# | grep Location
echo "
JAGEX [info] The in-game value of virtual currency may change at any time."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ea9f478a51202a0d# | grep Location
echo "
JAGEX [info] Caps may be placed on how much virtual currency may be obtained or moved"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/49bdf6f21314110b# | grep Location
echo "
JAGEX [info] Virtual currency cannot be refunded, and has no real world value..."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e8c38b4447a050e9# | grep Location
echo "
JAGEX [BAD] You don&#39;t own virtual currency, and your use of it can be revoked at any time"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/96fbe1e0a86dad0d# | grep Location
echo "
JAGEX [info] No moving digital currency between products."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/362e997260f57214# | grep Location
echo "
JAGEX [BAD] All virtual currency expires 12 months after acquisition, unless specified as sooner"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/31162823779f1e95# | grep Location
echo "
JAGEX [info] Refunds for EU customers"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3191fde1632ea70b# | grep Location
echo "
JAGEX [good] If you cancel your subscription you may continue to use it until credits expire"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d13c83c191f82b42# | grep Location
echo "
JAGEX [info] You may cancel your subscription at any time, unused portions are not refunded"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7f7f47196f333f9d# | grep Location
echo "
JAGEX [info] Jagex may bill you if you allow others to use your subscription"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7b4a04e20f914f3f# | grep Location
echo "
JAGEX [info] Subscriptions will renew 72 hours before the end of each period"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/52c85680cd04e2a9# | grep Location
echo "
JAGEX [good] Fees."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/574af60d36616233# | grep Location
echo "
JAGEX [bad] No refunds for deleted accounts or canceled services"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/cd8087ebbd31363a# | grep Location
echo "
JAGEX [bad] You give Jagex rights to your content"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5e668def0de1bd99# | grep Location
echo "
JAGEX [neutral] You must own the rights to any content you provide or upload"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e1faabb058a231cf# | grep Location
echo "
JAGEX [neutral] You must provide valid identity information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b45b4514485080c7# | grep Location
echo "
JAGEX [bad] Jagex can share your content and history to authorities at any time"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/76dd7286764d3899# | grep Location
echo "
JAGEX [neutral] Failing to follow games rules is prohibited"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6e4dfb0ed1a9cecd# | grep Location
echo "
JAGEX [bad] Jagex may stop offering a product at any time."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/de9fdc2fa18c1670# | grep Location
echo "
JAGEX [bad] Jagex owns your account and the content or creations of your account"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ea8a4b986b62f407# | grep Location
echo "
JAGEX [bad] No Alternate Client Software"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/456981ea6b88dc21# | grep Location
echo "
JAGEX [neutral] Usernames must not contain trademarks or be offensive"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/958ccc020ae35611# | grep Location
echo "
JAGEX [bad] Right to use products or software may be revoked at any time."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e316517315d710b2# | grep Location
echo "
For paid users, TOS and Privacy Policy changes don&#39;t apply until the next renewal date"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/58a5cd8207098484# | grep Location
echo "
JAGEX [bad] For free users, TOS and Privacy Policy changes occur instantly without notice"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f9b4fc3715686e45# | grep Location
echo "
JAGEX [good] Accepts and answers questions relating to their policies"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d82b105809c23ac2# | grep Location
echo "
JAGEX [neutral] Muted and banned accounts continue to use membership credits"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/bbad229fb4886e9c# | grep Location
echo "
JAGEX [bad] Banned accounts lose their account, characters and any in-game items or currency"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4f4531f31653a7cf# | grep Location
echo "
empty terms of services"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d4dae197af5bc417# | grep Location
echo "
BitTorrent Sync does not keep a record of which files are transferred"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3cf25146e2a3d4ad# | grep Location
echo "
Spotify tells users of privacy policy changes"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b8f754e05d365ee5# | grep Location
echo "
Spotify doesn&#39;t guarantee data securit"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/681e14a759d8a4a2# | grep Location
echo "
Spotify may transfer and process your data to somewhere outside of your country"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/344e58edf3d5770a# | grep Location
echo "
Spotify states risks of keeping information public"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2aeb9b97811ac5dd# | grep Location
echo "
No promise to inform regarding law or government requests"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d3f311e4983dd107# | grep Location
echo "
Spotify uses third parties"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b0af3d96d5c4457b# | grep Location
echo "
Spotify warns of third party uses"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/53b0776a9f30338b# | grep Location
echo "
Spotify defines intended use of your information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e0c1f534654a864c# | grep Location
echo "
Spotify may merge your new information with what they have currently"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d720af34d8266e03# | grep Location
echo "
Spotify uses a third party to process payments"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d9c4be7fdda5dd6a# | grep Location
echo "
Spotify defines information may they collect"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/daf00022a17230a7# | grep Location
echo "
Spotify can remove content at any time for any or no reason"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d62de138439418a1# | grep Location
echo "
Spotify has a broad copyright license"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4ac89bc1885023a3# | grep Location
echo "
Spotify provides limited solutions for software problems"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/67a1885060ae81cc# | grep Location
echo "
Spotify doesn&#39;t guarantee quality of service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6b416ca71f293c04# | grep Location
echo "
Spotify doesn&#39;t provide refunds"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1160ef8379c98eb8# | grep Location
echo "
Your data is accesible to Spotify&#39;s trading partners"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ba2c503c55a993ae# | grep Location
echo "
Spotify price changes take effect immediately"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8261f13bf3446d86# | grep Location
echo "
Spotify uses different agreements for special offers"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f14173eddb84d00c# | grep Location
echo "
Spotify&#39;s TOS is only translated into a few languages"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/457470eb0fab739a# | grep Location
echo "
Spotify allows users to unsubscribe at any time"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d4e759f1415a3b23# | grep Location
echo "
test"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/32a1fe764e49592b# | grep Location
echo "
FW: Hugo Roy (@hugoroyd) replied to one of your Tweets!"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/fb448a6d88f4998f# | grep Location
echo "
WhatsApp found to be violating data protection/privacy laws in Canada and the Netherlands"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5e0e4f0964ec179c# | grep Location
echo "
Trying to find terms. Google Maps for iPhone collects &quot;anonymous location data&quot; by default - but is it really &quot;anonymous&quot;?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/54b3c0dd4e3e41f5# | grep Location
echo "
It pays (literally) to read EULAs"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/51b203122c785564# | grep Location
echo "
Craigslist: Inability to delete posts or accounts."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9dc4c15c34d4ba94# | grep Location
echo "
Diaspora"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6295ac3e7db50957# | grep Location
echo "
Microsoft releases report on law enforcement requests"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/40cd97bc8f30ce84# | grep Location
echo "
Article from The Nation: &quot;Small Print, Big Problem (Part II: Remedies)&quot;"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/663f099a84622b22# | grep Location
echo "
Fitocracy ToS, paragraph 7, Changes to ToS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/23857812d4ca9ce8# | grep Location
echo "
Article from The Nation: &quot;Small Print, Big Problem (Part II: Remedies)&quot;"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5bebd89e105ca468# | grep Location
echo "
Change of eBay ToS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e27314c134b19c03# | grep Location
echo "
review policy: jurisdictions and availability in specific countries"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/08911b5bdf373593# | grep Location
echo "
(title unknown)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a5d2c9754e40ac26# | grep Location
echo "
PayPal terms modification"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/483932c367e32232# | grep Location
echo "
(title unknown)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/752a6f0627ae06f8# | grep Location
echo "
paypal changes terms about lawsuits again"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/284e74bac38c0e1b# | grep Location
echo "
transparency reports"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8974110aa5f9f326# | grep Location
echo "
who wants to help create an html form on tosdr.org?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1ce47710bc62a228# | grep Location
echo "
Mega.co.nz will only disclose your data if there is a reason to"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/bf210bb9cab46f68# | grep Location
echo "
Mega.co.nz welcomes questions and comments regarding their privacy policy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/da5bb9d07afaa4e0# | grep Location
echo "
Mega.co.nz terms have no class action waiver"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/fa140d0a2378e0b1# | grep Location
echo "
Mega.co.nz are not liable to you, but you are to them"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/27f1d65e14adb3f0# | grep Location
echo "
You may not use Mega.co.nz in any United States or New Zealand embargoed countries"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/11731f15a05a8164# | grep Location
echo "
Mega.co.nz instructs you how to file a Copyright Counter Notice"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4719563590d423a0# | grep Location
echo "
Mega.co.nz reverse-engineering clause"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/08702387909ae5f2# | grep Location
echo "
Mega.co.nz uses client-side encryption"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c3c9aeac794cd280# | grep Location
echo "
Mega.co.nz may only use your data to provide its service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/15d7b92481de53d6# | grep Location
echo "
mega.co.nz terms link to open source code seems broken"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2cef9ba265b06c05# | grep Location
echo "
mega.co.nz may delete your data immediately when they suspend your account"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f917a7edd43948cd# | grep Location
echo "
mega.co.nz de-duping clause seems to make no sense"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4cf09d6baf7606a1# | grep Location
echo "
on mega.co.nz, you are responsible for the behavior of other users"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/12a9077fda0b5dca# | grep Location
echo "
mega.co.nz may change their terms through just a website announcement"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8a56b0d7a1c162f6# | grep Location
echo "
Mint.com provides contact details for if you have questions about privacy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/563e798d85904f2f# | grep Location
echo "
Mint.com databases are protected from general employee access"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/30031179cc20adb5# | grep Location
echo "
Mint.com may transfer your data as part of a business transfer"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/18ae7d7c9cdc6eef# | grep Location
echo "
Mint.com will disclose your information if necessary or appropriate"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c0ad8bed931b6147# | grep Location
echo "
Mint.com does not allow advertisers to spy on you"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/137ca8a73371f409# | grep Location
echo "
Mint.com will not use your data for other purposes, and providing it is optional"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2eeffe8cfed28f9f# | grep Location
echo "
mint.com is TRUSTe certified"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7bdd4f92dccdf9bb# | grep Location
echo "
Mint.com explicitly commits to maintaining confidentiality"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c7be358d1cae502e# | grep Location
echo "
mint.com iOS app not available in Cuba"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f19a293739634d84# | grep Location
echo "
mint.com jury and class action waiver"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b87227fb0ee12f31# | grep Location
echo "
mint.com may change the terms at any time, but will display a change date"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8de282b5f65ceb52# | grep Location
echo "
Your data will be removed within 48 hours of deleting your Mint.com account"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/70c429925e63d6cb# | grep Location
echo "
you shall indemnify mint.com"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5c7bc6fce8abc2ff# | grep Location
echo "
Mint.com gets a license on the content you post"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/949fd05db6de96d8# | grep Location
echo "
you agree not to reverse-engineer mint.com&#39;s software"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/eddffb2ef0c1ba09# | grep Location
echo "
Mint.com may not use your data other than to provide the service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1088446e75433ed6# | grep Location
echo "
two apparent typos in section 9 of mint.com terms"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b773d7ea0f2fa458# | grep Location
echo "
Mint.com makes no warranties as to disclosure of information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2c5aead2ff878cff# | grep Location
echo "
Mint.com gets a license on your feedback"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9831e78f9738a500# | grep Location
echo "
mint.com requires you to enter true information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7f4018931fbac55b# | grep Location
echo "
mint.com has personalized ads"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4c4a9b4f2018a802# | grep Location
echo "
Mint.com may change their terms at any time without pro-active notice"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c39e7880e79b8229# | grep Location
echo "
Mint.com requires you to be of a legal age"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a3e4b73f9cf075ae# | grep Location
echo "
Amazon Kindle Content is licensed, not sold, to you by the Content Provider"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ce0c9652798cb84e# | grep Location
echo "
self-regulatory program for online behavioral advertising - opinions?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e6329a00dbb26118# | grep Location
echo "
Amazon will fingerprint your browser"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d456243b162dbd04# | grep Location
echo "
Amazon gives contact info to answer your questions about privacy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/199a0839f6ef3ed3# | grep Location
echo "
Amazon allows you to switch off personalized ads"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/39e81f3e657cba0a# | grep Location
echo "
Amazon emphasizes you can always choose not to provide information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7de960c23e952249# | grep Location
echo "
Amazon may release your data when they believe it appropriate"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b764dc86f8ea1cb8# | grep Location
echo "
Amazon may sell user data as part of a business transfer"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d7385c7913efde73# | grep Location
echo "
Amazon&#39;s providers may not use your data for other purposes"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7891f2e6d93c1a8c# | grep Location
echo "
Amazon does not sell your data"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1569010579936b18# | grep Location
echo "
Amazon smartphone app will track your movements, and fake &quot;opt-out&quot; suggested"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/446053f8815d1ef8# | grep Location
echo "
Amazon cookies you on other websites"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0b3be9409a376c5a# | grep Location
echo "
you agree not to reverse-engineer Amazon&#39;s software"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8cdd9496df0456c8# | grep Location
echo "
Amazon class action waiver"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9a4a81984381570c# | grep Location
echo "
Amazon damage waiver"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/dc2a914832a0a943# | grep Location
echo "
&#39;additional software terms&#39; is a broken link in Amazon ToS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/09f2eab0dec25747# | grep Location
echo "
you will indemnify Amazon for all claims resulting from content you supply"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5d3d7c35234b1ad4# | grep Location
echo "
Amazon reviews copyright license"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1cadef101d40f396# | grep Location
echo "
Amazon forbids political campaigning in e-cards"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/16a47d96d0dc7d81# | grep Location
echo "
Amazon reserves the right to [...] terminate accounts [...] in its sole discretion."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/22ae2359562f7279# | grep Location
echo "
If you are under 18, you may use the Amazon Services only with involvement of a parent or guardian."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4a745baa019a3f1e# | grep Location
echo "
Amazon.com equate posting notices with sending communication"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/81e80373cbbb069f# | grep Location
echo "
Amazon.com provides change logs of privacy policy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f902a20715c542b2# | grep Location
echo "
https://www.everpix.com/legal/ terms.html"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f078f8c37f870763# | grep Location
echo "
github URL changed from &quot;didnotread&quot; to &quot;tosdr&quot;"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0deda71b2d96bbf1# | grep Location
echo "
Apple can remove Content at any time from iCloud without prior notice at its sole discretion if content is &quot;objectionable&quot;"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7d627014a3063f6e# | grep Location
echo "
December-January-February Report"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/14e2d0dbe4966f3b# | grep Location
echo "
Habbo (Sulake) may modify settings of any Device you use to access their Services"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/dca887720556d74f# | grep Location
echo "
ToS;DR non-profit association"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1537d3d5805d6128# | grep Location
echo "
Tweetdeck - bad"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6cc1cbd8e52f1e8b# | grep Location
echo "
(title unknown)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4f42a47671b41e56# | grep Location
echo "
blogpost analyzing Mega privacy policy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f32cdae6f1fe6bb4# | grep Location
echo "
Travelzoo Says Vouchers Can be Redeemed for Cash (Follow-up question at the end)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1605a24eaa0737e7# | grep Location
echo "
Mega"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/16e002156ca0d1e1# | grep Location
echo "
This Sunday, a review of the new Instagram Terms and Privacy policy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0f463d731c6211b0# | grep Location
echo "
weebly lets you opt out of data collection for targeted ads"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0bfd47ac66d99b47# | grep Location
echo "
weebly settles disputes in court, not through binding arbitration"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/417f59f2ef4f0422# | grep Location
echo "
weebly appears not to use your content for advertising purposes"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/556d975a2696c63b# | grep Location
echo "
weebly appears to make it easy to delete your account"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e21ca534ce7a8f3b# | grep Location
echo "
weebly might send you unwanted mail, but you can opt out if you&#39;re savvy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/081d1d75058e3981# | grep Location
echo "
weebly provides a legitimate way for students under 13 to access (via education.weebly.com)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/979daec479b14e6b# | grep Location
echo "
weebly doesn&#39;t place TOS in prominent location"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/82a26f7fb667fc0b# | grep Location
echo "
Weebly (website / blogging service)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/233a673370af10e3# | grep Location
echo "
(title unknown)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/92e7c83dde6cd83a# | grep Location
echo "
Status update on the project&#39;s finances"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/dfed4a1ef4ab804e# | grep Location
echo "
Common violation: accessing the service (which includes website) implies bound by TOS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c175301ebae841e6# | grep Location
echo "
(title unknown)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9dfd1b3f89b5803b# | grep Location
echo "
[Fwd: Sony Asks Gamers To Waive Right to Sue]"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/bfe4393c9377d157# | grep Location
echo "
natural rubber"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ed22368610b5f684# | grep Location
echo "
EduCreations"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/11fa8a8a219988ce# | grep Location
echo "
rubber order"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/621ffc4aeb44e2bf# | grep Location
echo "
AUDIOTOOL.com does not claim any ownership rights in any Content deriving from User."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6dff39f6ab4e602a# | grep Location
echo "
freight forwarder &amp; logistics provider shared photos with you"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/31c994dffb7bb990# | grep Location
echo "
Most EXCELLENT initiative"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/17f65421261e38b8# | grep Location
echo "
Flattr uses third-party advertising cookies"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b4cd8baf4e6dcf7a# | grep Location
echo "
Feedback sent to Flattr is not confidential"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/aec8515d1f09092d# | grep Location
echo "
Flattr emails are opt-out"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d4f398af758b8908# | grep Location
echo "
Flattr informs users that other companies provide anonymity services"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b8ca0668464594d0# | grep Location
echo "
Flattr may use analytics software and third-party analytics software to observe trends"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5d38b1c500de08a4# | grep Location
echo "
Flattr logs information about you and uses it to maintain its service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ccff6eb895bab9b5# | grep Location
echo "
Flattr tracks your usage on third-party sites across the internet"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/65c2df61938e3f45# | grep Location
echo "
Flattr has an age requirement of 18"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d2973830371c8b67# | grep Location
echo "
Lastpass.com choice of court is Fairfax, VA"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/fb3e253a66602294# | grep Location
echo "
LastPass.com Idemnification"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b9d79c6c4e07d89f# | grep Location
echo "
LastPass.com is not liable for data loss or other damages"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f82a54373d3d881a# | grep Location
echo "
LastPass.com: You are solely responsible for the security of your account"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/bf2847f132cbb386# | grep Location
echo "
LastPass will not provide refunds if they terminate you account or terminate the service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/51451c1d2a539421# | grep Location
echo "
LastPass.com may terminate your access to the site at any time for any reason"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/64f30a7e66689e4b# | grep Location
echo "
LastPass.com: Emails sent to lastpass may be published publically"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/bb5ee1f75a418323# | grep Location
echo "
LastPass.com: No assurance of an opt-out method for non-transactional email"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/23732068da353e57# | grep Location
echo "
LastPass.com: No promise to inform you of government requests"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5d440f42c786a175# | grep Location
echo "
LastPass.com requires minimal information to create an account"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/006d03c1ed1f445d# | grep Location
echo "
LastPass.com treats IP addresses as personally-identifiable data"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8da4c5253b72f4cc# | grep Location
echo "
LastPass never has clear-text versions of your critical data, including passwords or master password"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/03f84f8d8764d1b8# | grep Location
echo "
TinyURL: No warning if account or service is terminated"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/bc326fc0de2da82b# | grep Location
echo "
TinyURL.com uses third party cookies for targeted advertising"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/10ba17eb0f681c5f# | grep Location
echo "
TinyURL.com: Your information is shared in the event of a merger"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9921f135ed364b77# | grep Location
echo "
TinyURL.com: No promise to inform of government requests for information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e02888d17a48cc21# | grep Location
echo "
TinyURL.com may share personally identifing data with third parties and advertisers"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/227e902a1003d336# | grep Location
echo "
symbaloo (symbaloo.com)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3174fe9de57a27f8# | grep Location
echo "
ABC Website Australia - Tos - Very broad right to use your material"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e3530362376b2bce# | grep Location
echo "
Tinyurl&#39;s TOS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/668d537857d228c4# | grep Location
echo "
LastPass TOS/Privacy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6ac232c71619e9f1# | grep Location
echo "
Flattr TOS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/58f740da9cd7471a# | grep Location
echo "
Maybe an interesting book? Boilerplate"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8df2dd70f3d040da# | grep Location
echo "
TOS on airbnb (part2)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9cbe83f95eebed1e# | grep Location
echo "
airbnb TOS unrated"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e42ea3d6e01f8704# | grep Location
echo "
Instagram"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/45326ea5487194ba# | grep Location
echo "
Softpedia may terminate some or all of its services or content at any time without nice"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d7924e0901f80ac6# | grep Location
echo "
Softpedia choice of law is Romania"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b71180db7aaf439d# | grep Location
echo "
Softpedia indemnity"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9736ee4e8e232ba9# | grep Location
echo "
Softpedia claims ownership of text submitted to the site"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c0e24b92a1bfcb6c# | grep Location
echo "
Softpedia is for personal, non-commercial use only"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f73f1d96d6f2c352# | grep Location
echo "
Softpedia may terminate your account at any time for any reason"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c6924d87d9b05960# | grep Location
echo "
You warrant the information you provide on registration to softpedia is accurate"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c84b0585200b93ef# | grep Location
echo "
Softpedia, Children under 13 must have parental consent"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5275e7b72d423f33# | grep Location
echo "
Softpedia makes no effort to inform of information requests"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1820fcb254481e2e# | grep Location
echo "
Softpedia may share data when require by law or in its best interests"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/23125ea5dfb78c9a# | grep Location
echo "
Good: Softpedia does not send unsolicited email"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1cfa21d5c05a4f58# | grep Location
echo "
Softpedia only shows aggregate information to third-parties"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a271bcd010be7fc5# | grep Location
echo "
Softpedia uses third-party targeted advertising"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2902723fd04d79f3# | grep Location
echo "
Good: softpedia gives users choice to accept personal information handling changes"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b9173e4cf1f79327# | grep Location
echo "
Websaver provides an email opt-out method"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/585a7292ec836987# | grep Location
echo "
Websaver.ca uses cookies and web beacons for advertising"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f27cb6ac277d3fd4# | grep Location
echo "
Webserver marketing and third-party marketing is opt-out"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f38ef9acc45e7013# | grep Location
echo "
Websaver service requires registration"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9b10175342111f2a# | grep Location
echo "
Websaver.ca Choice of court is Montreal. Quebec"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/195ffdc7e46c6321# | grep Location
echo "
Websaver may terminate its service at any time without notice"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7bbe3d3015ab5942# | grep Location
echo "
Websaver can terminate your account for any reason without notice"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/86b971c536897d82# | grep Location
echo "
Websaver can share your personal information with any third party without legal requirement to do so"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c97f385fd80ff7f8# | grep Location
echo "
Websaver.ca doesn&#39;t promise to notify you of government requests"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/858c6b9d9e2eae1a# | grep Location
echo "
You agree to defend, indemnify and hold blameless websaver.ca"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/fec180b7ac4c8348# | grep Location
echo "
Websaver.ca only allows one account per household"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3d69ee06471585d7# | grep Location
echo "
Web saver.ca doesn&#39;t allow frames"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9187f19017708e01# | grep Location
echo "
Websaver.ca can use feedback for any purpose without attribution"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ba2abb8cc4eb2052# | grep Location
echo "
Websaver isn&#39;t responsible for missing mail"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a51f0f0560fe0f19# | grep Location
echo "
Websaver.ca isn&#39;t responsible for unauthorized access"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6b35c5f9d77c1bac# | grep Location
echo "
Websaver.ca: no robots/spiders"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f3a6bc0fa50faeb5# | grep Location
echo "
Websaver.ca age requirement of 18"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/efad80c6e7a621ce# | grep Location
echo "
Terms of Service included in the Softpedia software database"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/33fb7ba48a105a98# | grep Location
echo "
You can leave Cloudant at any time"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/549dbe05db5c204f# | grep Location
echo "
Cloudant.com"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/11c00f6da2aa746f# | grep Location
echo "
Cloudant will transfer Hosted Data and Personal Information if acquired"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/78375fc9a1553675# | grep Location
echo "
Cloudant hosted data may be temporarily accessed by technical staff"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ed1eaf3a947248da# | grep Location
echo "
Cloudant may share aggregated usage data with partners and third parties"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ecaf584348921ce2# | grep Location
echo "
You may request copies and alternations to the personal information Cloudant stores"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ded80ef1ccef81b4# | grep Location
echo "
Cloudant marketing emails are opt-out"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/73c29501e9bdc904# | grep Location
echo "
Cloudant uses third-party cookies and 1x1 images for ad tracking"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/13be7512426aa27b# | grep Location
echo "
Cloudant choice of law is Massachusetts"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a190b5b783d832df# | grep Location
echo "
Cloudant indemnification"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7feac2e7f63114d3# | grep Location
echo "
Cloudant will provide some integration assistance at no cost."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9bd1f27cc1aa7094# | grep Location
echo "
Cloudant liability is limited to SLA and having Cloudant correct the error, if feasible"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/03323674787b21a3# | grep Location
echo "
Cloudant will provide an exported copy of your data in the event of termination"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1830926b83c041bf# | grep Location
echo "
Cloudant will give 30 days notice before termination"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c959be5f8c9be466# | grep Location
echo "
Cloudant will make all attempts to notify you of legal demands for confidential information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ef761fe4ffe7eee6# | grep Location
echo "
Cloudant will only respond to requests for information if legally required to do so"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/46da839f0c9ad828# | grep Location
echo "
Cloudant will not share your data with third parties or use it beyond providing its service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/76ea3f507ac77392# | grep Location
echo "
Cloudant provides a SLA and will refund a portion of charges if levels are not met"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ded513aadea18cd6# | grep Location
echo "
Cloudant will inform you if emergency maintenance is occurring"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b45109395b86cc7b# | grep Location
echo "
Cloudant gives at least 1 business day notice of scheduled downtime except in emergency"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6f5081a6ba96c4e0# | grep Location
echo "
Cloudant lets you maintain ownership of your data"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2ecd94b971a5b520# | grep Location
echo "
Cloudant not responsible for unauthorized access to your account"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/63a12b8b333ef7b9# | grep Location
echo "
Cloudant accounts may only be used by one person (additional accounts can be freely created)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1e3c64257f69791d# | grep Location
echo "
Cloudant requires a real name to register"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d1fcb6969821c439# | grep Location
echo "
You must own or have rights to all data you store on Cloudant"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/954e51d39b0e46a5# | grep Location
echo "
Cloudant does not allow spidering/crawling"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7160a2f67e6c93f4# | grep Location
echo "
Cloudant users cannot share screenshots of their admin panel"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e4fc2f4f62904362# | grep Location
echo "
Cloudant requires you be of legal age to form a binding contract in the place you reside"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/35c1ba48fad31323# | grep Location
echo "
Grammarly doesn&#39;t list pricing without signing up"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e11008abbd816b19# | grep Location
echo "
Grammarly offers contact information for privacy questions"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b5b7ec98b48e2e31# | grep Location
echo "
(Good) grammerly Privacy policy is easy to read"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/93f4666581a4af0c# | grep Location
echo "
Grammarly uses third-party cookies and web beacons"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c5e094d7a20d7022# | grep Location
echo "
Grammarly makes no promise to inform of government requests"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d262b93a242c9d39# | grep Location
echo "
Grammar doesn&#39;t have to notify you because being acquired or merged with another company"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ead57e4dfd08014f# | grep Location
echo "
Grammarly will make reasonable efforts to notify you of changes to its service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f3a56c22b6ae1275# | grep Location
echo "
Grammarly uses google, doubleclick for tracking and ad targeting"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/36874eeacbd27288# | grep Location
echo "
Grammarly choice of jurisdiction is San Francisco County, California"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6b3905147a6d2287# | grep Location
echo "
Grammarly liability is limited to the last 12 months of paid fees."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5744c4188c98f8cc# | grep Location
echo "
Grammarly indemnity"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c1711f1fe8228926# | grep Location
echo "
Feedback and suggestions become the property of Grammarly"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/25ffdd946ad02783# | grep Location
echo "
Grammarly doesn&#39;t claim any copyright or ownership over your work"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7c2cd653b80400c3# | grep Location
echo "
Grammarly emails are opt-out"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/fa02bdff1dc19744# | grep Location
echo "
Grammarly will refund remaining subscription if you quit the service within 10 days of a ToS change"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7bac6e7a5a40f4c6# | grep Location
echo "
Grammarly only allows you to upload file you have full rights to"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4fccaf2d84af7faa# | grep Location
echo "
Enterprise Subscribers are treated differently and are given notice before termination"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1f42c5ee56b42b22# | grep Location
echo "
Grammarly doesn&#39;t provide refunds."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d198dbe0739134e7# | grep Location
echo "
Grammarly can delete your account at any time for any reason (including exceeding usage limits)."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a4f2d37fe2195d58# | grep Location
echo "
Grammarly trials require a credit card and automatically renew unless canceled"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f421675ab8f20109# | grep Location
echo "
Grammarly fees may change at any time with 10 days notice, continued use is considered acceptance"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8a8f8800324b0efb# | grep Location
echo "
grammarly.com Trail is for non-commercial use only"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/19c06776e0e0d07c# | grep Location
echo "
Grammarly requires a real name."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2de5660683d4bee5# | grep Location
echo "
Grammarly not responsible for unauthorized access"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4714aa198c9dc955# | grep Location
echo "
grammarly.com Cannot download, store or print resources unless specifically given permission"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9158f761e62f938d# | grep Location
echo "
grammarly.com Personal use only"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/fc31e42edc2095c4# | grep Location
echo "
grammarly.com Spidering and bots are forbidden"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/dc981125669e1650# | grep Location
echo "
grammarly.com You agree not to make a similar service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0b2b9194f4cbebd4# | grep Location
echo "
grammarly.com/terms Usage restrictions"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/40b7ea81c1cdf0dd# | grep Location
echo "
grammarly.com age limit of 18"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/24b01d890a1fa8a1# | grep Location
echo "
JSON -&gt; CouchDB sync script"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1f89362fd5ad22ce# | grep Location
echo "
PHP validation script"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/dcfccb7fa64895a8# | grep Location
echo "
Skype Education makes broad claims about owning your content, and it defines &quot;content&quot; broadly"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d9be6c96a4e317ef# | grep Location
echo "
Change in https://tos-dr.info/legal.html"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c58be2fbfeb92bb8# | grep Location
echo "
Are ToS;DR reviews and ratings stored in a database?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/dbc3ee9a3b7caa37# | grep Location
echo "
Facebook vote Re: Our Global Site Governance Vote"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0e3d289d55f2caa2# | grep Location
echo "
Yahoo! fails to implement https"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7a791d5e2e3d3a01# | grep Location
echo "
Change in https://tos-dr.info/legal.html"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7fd37ca7e2e58c3d# | grep Location
echo "
You may not scrape the site"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d40ad6cfe5fbf38b# | grep Location
echo "
[ENVATO] Credits are non-refundable"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ba0524deefbcb224# | grep Location
echo "
[bad] Money in account expires after one year."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/fc39400e82ed600a# | grep Location
echo "
No liability is accepted for improper access to your personal information."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d8c86e4e7767c3a0# | grep Location
echo "
You must provide your legal name upon registration and is shared with agents"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b34e7c8c7a63343c# | grep Location
echo "
You do not have to pay a fee to become a Member."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/eb4bda9235b1a5ff# | grep Location
echo "
$ Represent a credit system"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c167620edae73708# | grep Location
echo "
No guarantee of availability, and the service can be suspended at any time"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d25819dc8a7f7b6c# | grep Location
echo "
will indemnify and defend Envato"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7c109ea32fef53c7# | grep Location
echo "
Your account can be terminated for any reason without notice."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/90cd9f53e1d339e7# | grep Location
echo "
Age limit of 18"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/92ef29441fc11048# | grep Location
echo "
No assurance of notice of government requests"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/65bdfd863e1b936b# | grep Location
echo "
Notice only given for privacy policy changes (30 days)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1893715faea20f79# | grep Location
echo "
You may request a copy of stored personal information."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9dc6d24ff3a7a53c# | grep Location
echo "
Uses Third party cookies"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8d376aac1ff1bb27# | grep Location
echo "
Collected personal data used for limited purposes"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c878f7aa5c85f7a2# | grep Location
echo "
Uses temporary session cookies"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0de30659b51e0569# | grep Location
echo "
Jurisdiction is New South Wales, Australia"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5523a54c67e81938# | grep Location
echo "
No warranty is provided, and any liability is limited to the original cost of goods."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8d19fba809b422a5# | grep Location
echo "
Not responsible for the content of external links."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/78e5f80b78d66ca5# | grep Location
echo "
[ENVATO] Claims ownership of incoming links"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3c3339bc63fb13a3# | grep Location
echo "
Embedding the site is frames is not allowed."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/06a3f08022c891f3# | grep Location
echo "
Hot-linking and image downloading is not allowed"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/25254b9f1f0782c9# | grep Location
echo "
[EVENTO] Members choose the licensing and copyright of their submissions."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/49aef8ac68e5c371# | grep Location
echo "
faranow.com - no promise to inform about government requests"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c6c630f8018c9089# | grep Location
echo "
faranow.com may suspend the service at any time without notice"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2c27ecbbc6e8a619# | grep Location
echo "
faranow.com has an age limit of 13"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/930edc1ceea2b44c# | grep Location
echo "
Apple.com has an age restriction of 13 years"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2df207fca1e45a07# | grep Location
echo "
Apple provides an opt-out method for Apple targeted advertising"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0a730ec97ba3cbd5# | grep Location
echo "
Apple.com limits legal recourse in a number of ways"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1e76f68e8e6b2267# | grep Location
echo "
Apple.com juristiction"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/84314ede4fb3edf7# | grep Location
echo "
Allrecipe may delete account, content at any time without reason."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/73461ab8aacef8cb# | grep Location
echo "
Allrecipe.com jurisdiction is Washington"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/bb985f5e3ccee05c# | grep Location
echo "
Allrecipe.com indemnification"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/186fe01d8b3d7d39# | grep Location
echo "
Allrecipe.com receives extensive license to use and commercialize your work"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e0834db6cda9545a# | grep Location
echo "
Allrecipe.com seems to think it can limit free-speech linking"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9ae6803c36caf2c4# | grep Location
echo "
allrecipe.com users in California get additional rights to opt-out"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3bf9735564c584c5# | grep Location
echo "
allrecipe.com provides a total email opt-out process"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/61057dbfdec7ea1f# | grep Location
echo "
allrecipe.com has a age limit of 13"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7c68fc9c57325d65# | grep Location
echo "
allrecipe.com uses cookies, web beacons and flash cookies to target advertising."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d00f3378de50430b# | grep Location
echo "
fightforthefuture.org/thecente rforrights.org does not explicitly provide gov&#39;t request notice"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9fe7b7f3361bd3f1# | grep Location
echo "
fightforthefuture.org/thecente rforrights.org shares user lists &quot;cooperating organizations&quot;"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/bb72348169555abf# | grep Location
echo "
Envato domains read through"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/711c61fe19224cd6# | grep Location
echo "
(title unknown)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1ff62dd814b52625# | grep Location
echo "
Monthly report from Hugo"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4ee88d00d112839c# | grep Location
echo "
Spotify end user agreement and privacy policy review"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6d9a42d455e7a0b0# | grep Location
echo "
http://www.grammarly.com/terms"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f0c3ac0aaa5db5dd# | grep Location
echo "
Change in http://tos-dr.info/legal.html"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9a407bdf7b944551# | grep Location
echo "
No trial by jury?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a8ac41f32ec4636c# | grep Location
echo "
alternative to dropbox: tidy.io"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/26723c242e61fdb7# | grep Location
echo "
[Fwd: Fwd: Important Announcement from Evernote]"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f60cd6b586504757# | grep Location
echo "
(title unknown)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f1b6443331f3f757# | grep Location
echo "
First comment; about &quot;blank contracts&quot;"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f51b442bf3a15591# | grep Location
echo "
Breakdown of EULA or ToS components"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/42945fbd9bbe0a70# | grep Location
echo "
Clearware.org - Making Sense of Software"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/58ed2cf0668040f3# | grep Location
echo "
&lt;no subject&gt;"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9bfd12dc3594062a# | grep Location
echo "
dhl Senior Delivery Officer"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d871621ea057b71b# | grep Location
echo "
http://www.abbyyonline.com/en/Account/Register/?service=finereader&amp;back=%2fen"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/52b66cab3386dde1# | grep Location
echo "
Wasabi World Wide Heavy Industries, LLC"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/88216dc50c72fa0f# | grep Location
echo "
Hello Dear."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/98bc8f26d136807e# | grep Location
echo "
wot and privacyparrot"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/90c84df69ef837b3# | grep Location
echo "
Google provides Insufficient information to users about personal data processing operations"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7454a7790bea8758# | grep Location
echo "
CNIL&#39;S Report on Google"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/aa1eaf3992157f41# | grep Location
echo "
iCloud TOS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2996676e03af91bc# | grep Location
echo "
TermOs Service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/660120313240ee48# | grep Location
echo "
ebay - Summarized privacy policy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5d4eb49f853ea4a4# | grep Location
echo "
freedom of speech"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8cc1f577ab3cc3cd# | grep Location
echo "
Zooniverse.org [Good] - user keeps ownership of any contribution"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3e758681721e7507# | grep Location
echo "
minecraft tos"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/273eebe42d92d31f# | grep Location
echo "
Funny: Here&#39;s a stereotypical but exaggerated ToS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7c5ce49354e16b8e# | grep Location
echo "
Discussion: Inability-to-delete-accounts"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c3e61841c8947a1f# | grep Location
echo "
Fwd: PayPal aktualisiert die AGB"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e8dbb054142e7128# | grep Location
echo "
Analyzed Wikimedia Foundation ToS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d1ba170871cf801c# | grep Location
echo "
rec.applyyourself.com - accessing service constitutes acceptance; only displayed after login"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c8124a6a4e546195# | grep Location
echo "
PrivacyFix"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/64bf96b59f3ea85b# | grep Location
echo "
Nokia Account - How they share your data"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/81ec9ce3dcf3dca7# | grep Location
echo "
Nokia Account - Applicable law"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d98e7d79564326af# | grep Location
echo "
Nokia Account - Refunds and cancellations are difficult"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a4476b51180d1dff# | grep Location
echo "
Nokia Account - You can be charged without notice"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/67fa42e971ca6fc6# | grep Location
echo "
Nokia Account - You can&#39;t use for commercial use"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/317c3cee78ebae19# | grep Location
echo "
Nokia Account - Your data keeps copyrighted to you"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/95f688e64950a60b# | grep Location
echo "
Nokia Account - No confirmation that data is completely removed"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a7f0a30ec241e4ce# | grep Location
echo "
Nokia Account - You may terminate your account anytime"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/22da46e851742d0c# | grep Location
echo "
Nokia Account - Info sent to Nokia in first use and every update"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/66d25bc71e898ca7# | grep Location
echo "
App.net : &quot;Changes to these Terms&quot;"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/cea820f282d9fe7a# | grep Location
echo "
Codeschool"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8c1c5dd58e09476e# | grep Location
echo "
Verizon selling web history and data about location (30 days opt-out)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/cbb29716469ee407# | grep Location
echo "
indiegogo may send you emails"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c50fa998b66a2213# | grep Location
echo "
[site suggestion] TOS:DR"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8a9d3adbc027eb2e# | grep Location
echo "
(title unknown)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/eccf5c3d35bcfa2a# | grep Location
echo "
[site suggestion] Identi.ca"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/95b447fa79f2293b# | grep Location
echo "
Pseudonyms allowed"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/435a032b8980beec# | grep Location
echo "
No pseudonyms allowed"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/27a17b746f1da92a# | grep Location
echo "
You must provide your legal name upon registration"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/23ff2c54ff09f166# | grep Location
echo "
British Airways (ba.com) - unilateral changes to terms of service via web posting"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/35e07416a5d97332# | grep Location
echo "
Skype can change agreement without notifying users"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2028483b8c5e9332# | grep Location
echo "
Propaganda posters"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1bb3c2ecb964b4d4# | grep Location
echo "
Terms may be changed any time at their discretion, without notice to the user"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/95be7468bb9e8284# | grep Location
echo "
fivesquids.co.uk"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2fe30bc78dd35599# | grep Location
echo "
Gone"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2b8c9ff3af66d368# | grep Location
echo "
(title unknown)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/366f6c385b46dd00# | grep Location
echo "
*Changing Terms* on Kippt.com: may change their privacy policy without prior notice"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4489447e88709283# | grep Location
echo "
*Right to leave the service* on kippt.com: nothing about this topic on the privacy policy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/800fca139bddfd66# | grep Location
echo "
Square TOS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6291059cbf38f496# | grep Location
echo "
scotiabank.com/Alerts terms"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/af6888c63ef0cd39# | grep Location
echo "
Can Apple ID and/or iCloud accounts be deleted?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/847cbbbe4d9c8a56# | grep Location
echo "
weights for various &#39;changes&#39; and &#39;dialogue&#39; clauses"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3c14ad2a2e90760e# | grep Location
echo "
Whatsapp Account Removal"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d0ea4b64624230f6# | grep Location
echo "
app.net defend&amp;indemnify clause"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e870e58bd5f4d42f# | grep Location
echo "
(title unknown)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6042b5cb72c59813# | grep Location
echo "
blogpost &quot;Boingo Wi-Fi hotspot Customer Agreement and Privacy Policy explained&quot;"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/35c7c96d812a4d94# | grep Location
echo "
(title unknown)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9ca93e53b4ad9f99# | grep Location
echo "
blogpost &quot;Evernote puts you in charge&quot;"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ddd397cc78a5c48e# | grep Location
echo "
additional data points as opposed to contractual data points"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0a80db90f671381f# | grep Location
echo "
[Good] OwnCube"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b439c8f52128aefe# | grep Location
echo "
If we reach our Indiegogo target, then Google will award matching funding"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/820367ad6ccfe7b1# | grep Location
echo "
App.net terms are in a public repository (and current info is wrong)."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/23b8bed843341956# | grep Location
echo "
Subtle issue with not being able to delete an account in a service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a6cc07283cbc447d# | grep Location
echo "
Fwd: Facebook Now Knows What You&#39;re Buying at Drug Stores"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/91a4d2ac3b9710c6# | grep Location
echo "
CouchSurfing keeps the license on your content, even after you close your account"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d7059c56e8822766# | grep Location
echo "
you cannot use CouchSurfing if you are from certain countries"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1bcc34d99dd1291c# | grep Location
echo "
CouchSurfing may revoke the right to link to them"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a1d856fb3d6fa268# | grep Location
echo "
CouchSurfing may close your account at their sole discretion"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/066cc13c6c87196d# | grep Location
echo "
CouchSurfing becomes the owner of ideas you give them"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4a1c02323341776a# | grep Location
echo "
CouchSurfing copyright license on user data is broader than necessary"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/75057c9e8b6685f2# | grep Location
echo "
CouchSurfing will censor the content you upload at their sole discretion"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/adf2c1f5e0d536d9# | grep Location
echo "
you cannot blame CouchSurfing for disputes you have with other users on there"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e52b5581ec3955b1# | grep Location
echo "
CouchSurfing promotional communications are opt-out"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7bc9060efe0222b4# | grep Location
echo "
CouchSharing informs you about the fact that you can disable cookies"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6d819e7c12b747f2# | grep Location
echo "
CouchSurfing may retain your data after deactivation for legitimate business purposes"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a19d55bf19d6a1e3# | grep Location
echo "
CouchSurfing may share aggregated or anonymized information that does not directly identify you."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c0e85cf8bb1ccbfd# | grep Location
echo "
CouchSurfing will pass your data on to the new company if they enter in a merger"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c7d0437e0f9216a6# | grep Location
echo "
CouchSurfing tracks you"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/50cc93e112978efd# | grep Location
echo "
CouchSurfing may change their privacy policy without prior notice"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f6b20c8dfe8589f3# | grep Location
echo "
link to CouchSurfing new privacy policy is a broken link?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9d27f1c0c3bc5c26# | grep Location
echo "
CouchSurfing imposes community guidelines"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6242698f5ef442db# | grep Location
echo "
Cannot use CouchSurfing anonymously"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/277926c0b6c0d2b1# | grep Location
echo "
CouchSurfing.org shares your browsing behaviour with third parties (facebook)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/519d1d540e5b8e0c# | grep Location
echo "
Couchsurfing clearly invite you to contact them if you have any questions"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8b346835ca063b0c# | grep Location
echo "
BeWelcome is asking for community input to change their ToU"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3c249a955faf68b8# | grep Location
echo "
OwnCube is free software (AGPL)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6486ce230405d66a# | grep Location
echo "
OwnCube may change at any time without notice"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/36da757b6d184c6b# | grep Location
echo "
OwnCube can remove your account after complaints"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9da3ef45ffa5dd53# | grep Location
echo "
OwnCube - user data is not sold"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/433a4fb5198dc64b# | grep Location
echo "
(title unknown)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0cf119687df9a551# | grep Location
echo "
(title unknown)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/bd079782f8e20065# | grep Location
echo "
blogpost reviewing app.net ToS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3aa224012daec261# | grep Location
echo "
Deemed to have accepted Toggle&#39;s TOS by accessing their website (which hosts the TOS)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/44b12e9dbd1c7c7f# | grep Location
echo "
SimpleHitCounter"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1d478d02e2961aed# | grep Location
echo "
Creative Commons as a TOS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/526488a12e888c87# | grep Location
echo "
Coursera can change Terms of Service without notice and with immediate effect."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5d624528d32ad1be# | grep Location
echo "
We&#39;re already 25% funded! \o/ please help us keep up the pace"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4501aa8cb2539016# | grep Location
echo "
MySpace Terms &amp; Privacy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4aa43af673bfec50# | grep Location
echo "
FreeForums.org part of CrowdGather"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c6ce2e827bb13540# | grep Location
echo "
Users assign copyright to App.net, [Warning] Must defend and indemnify App.net"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d9a8437eef95be06# | grep Location
echo "
Everybody who reads this, please consider donating 10 euros of your own money"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ade25a38690b8441# | grep Location
echo "
Microsoft website TOS and PP."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/bf1b4e309f7f0ab0# | grep Location
echo "
24 days to decide the future of this project"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/84bdf7b3708c7e99# | grep Location
echo "
App.net: you may opt out of receiving promotional messages"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/44e7f822082f491d# | grep Location
echo "
App.net requires use of cookies and web beacons"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/777d798dbe8f13cd# | grep Location
echo "
Suggestion for Priority: Couchsurfing"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c22760ad8b1f1d3c# | grep Location
echo "
My Popular App Was Removed without Warning :( How to Appeal?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/59e9b63ad5152880# | grep Location
echo "
ToS Lorea"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f102c794c6021520# | grep Location
echo "
moving ToS;DR repositories"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f49e13f75a2ba0fd# | grep Location
echo "
transferred latest data points to staging server"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/bb0666d4502aa0e8# | grep Location
echo "
Hemos actualizado el Contrato de servicios de Microsoft, por el que se rigen muchos de nuestros serv"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1abb3bae19b32da8# | grep Location
echo "
Video for crowdfunding campaign"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6b146796ccff372c# | grep Location
echo "
Rapidshare users personal information for limited purposes"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/098c6484f44e3345# | grep Location
echo "
Rapidshare won&#39;t share information to a requesting authority without a legal basis"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/86523ee7bd9b161a# | grep Location
echo "
Rapidshare allows four weeks to terminate contract when changing ToU"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f817466f8ec83323# | grep Location
echo "
Rapidshare does not guarantee content damage"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/57b8941b6aab6a41# | grep Location
echo "
Rapidshare guarantees 99.5% availability"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/62d969f1869e06be# | grep Location
echo "
Rapidshare will delete files after 30 days of not been accessed"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4010fc2d7e49c1d1# | grep Location
echo "
Rapidshare does not index or open the files"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0d6ad69f162a7b8f# | grep Location
echo "
freeforums.org"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8154cbe76f64e5ab# | grep Location
echo "
Informe.com"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/862658d2d34fea44# | grep Location
echo "
nabble TOS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/08387f6d5ede592b# | grep Location
echo "
standardizing data point texts"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/95d7358adfbab5a6# | grep Location
echo "
data from knowprivacy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1c32e38f99afdeee# | grep Location
echo "
flattr terms updated 29 aug"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4df0438048604046# | grep Location
echo "
Deleting your account on Spotify"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a9e0ef74fc09c2f0# | grep Location
echo "
Digest for tosdr@googlegroups.com - 5 Messages in 4 Topics"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/27a98f24498e941a# | grep Location
echo "
The Truth About Abs .. Download N.o.w.!"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d4a71171c78f6d5e# | grep Location
echo "
Virgin Mobile USA"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2dbaa7baa87e1ac7# | grep Location
echo "
Fwd: Important Changes to Microsoft Services Agreement and Communication Preferences"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/55158731f04b9af2# | grep Location
echo "
&lt;bad point&gt; Microsoft : Trial and class action waiver effective 10/19/2012"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e916f9edd5e72554# | grep Location
echo "
Mint.com may use your financial information to advertise to you"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4b5a1507dacba779# | grep Location
echo "
Mint.com may change its privacy policy at any time, at its sole discretion"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/74548606eae7e48c# | grep Location
echo "
Toodledo term"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a8ed6bfde1a978e3# | grep Location
echo "
Couchsurfing TOS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3f4c55171ec21460# | grep Location
echo "
Evernote Terms of Service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/88f2ecba900ea4f9# | grep Location
echo "
PLC products bussiness opportunity"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e83f9ca476adabc0# | grep Location
echo "
Microsoft Bizspark - Use of Participant&#39;s trademarks and services marks without needing permission"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8de33bf3f2acee88# | grep Location
echo "
indeed.com--Data portability"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ba4b1d11fb47c2c5# | grep Location
echo "
indeed.com--scope of the copyright license"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/405f7650dc960c02# | grep Location
echo "
SpiderOak no refunds"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2fb845adf764da3a# | grep Location
echo "
SpiderOak will notify you of privacy policy updates"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8e8a89b3a04c618e# | grep Location
echo "
SpiderOak You can terminate your account"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1bfe85a089385402# | grep Location
echo "
SpiderOak jurisdiction in the State of Illinois, USA"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e84d1589a7f23b38# | grep Location
echo "
SpiderOak can not decrypt your files."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3a3e0a5876d708a7# | grep Location
echo "
yfrog - the social image share service of ImageShack"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9ac0a5c8ebcf6136# | grep Location
echo "
Cheat Happens"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c233feb12f34f7a3# | grep Location
echo "
(good and bad points) Stack Exchange"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5dfd9b9bd8a065b6# | grep Location
echo "
api question"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/fc32f00f7bdf4143# | grep Location
echo "
Blatent"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/90a6f3020975c2d5# | grep Location
echo "
Badoo"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0b4bcc39c254d36b# | grep Location
echo "
App.net may change it&#39;s Terms of Service at any time"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3021b1dc3b501ccf# | grep Location
echo "
WhatsApp allows you to delete your account"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9a98eef56cdf2f4a# | grep Location
echo "
WhatsApp may release personal information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/fccb1d995523593c# | grep Location
echo "
WhatsApp may sell your personal information such as phone number unless you opt-out"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/eba6e34da5acecd6# | grep Location
echo "
WhatsApp may use your phone number for non-marketing or administrative purposes"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/df29da273b1eda3d# | grep Location
echo "
WhatsApp may use your phone number for marketing messages"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f1222a3bdb06db88# | grep Location
echo "
Any personal information shared with WhatsApp is publicly available"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2d542313804ccae3# | grep Location
echo "
WhatsApp deletes content after delivering messages"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/215c44ac39fe3927# | grep Location
echo "
WhatsApp doesn&#39;t collect personal information besides the phone number"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c5c16b59c7dd3237# | grep Location
echo "
WhatsApp may require cookies"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3cf8f35a8be60dff# | grep Location
echo "
WhatsApp may change terms at any time, without notice"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a15fcd4fae8d2a11# | grep Location
echo "
To use WhatsApp you must be 16 years old"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4913a650e8a4f210# | grep Location
echo "
WhatsApp Choice of law: Santa Clara County, California"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/678fb08b7160779c# | grep Location
echo "
You indemnify Whatsapp from any claim related to your content"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7a0f6573087b1101# | grep Location
echo "
WhatsApp may terminate your account at any time, by any reason"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b9217fbb0b0bc5fb# | grep Location
echo "
WhatsApp holds unlimited copyright license on your Status Submissions"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/077a21734dc48df5# | grep Location
echo "
WhatsApp requires access to your contact list"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/616fd7009d3d355a# | grep Location
echo "
WhatsApp requires your mobile phone number"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4ba629b5c173a300# | grep Location
echo "
Translation"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4618859c48651bd2# | grep Location
echo "
Dropbox may delete your free account and data after 90 days of inactivity"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e734c5c66165413c# | grep Location
echo "
Dropbox has a no refund policy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f491e7403e9f5c3c# | grep Location
echo "
Dropbox deletes your content quickly upon request"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/cc9e42533e87da67# | grep Location
echo "
Dropbox doesn&#39;t share information with third-parties without consent"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d72671091a586f0e# | grep Location
echo "
Dropbox uses cookies to track users"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/46b603149abe95ef# | grep Location
echo "
Dropbox requires cookies"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/bd157a4feaae721c# | grep Location
echo "
Dropbox Choice of law: California"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5a905527327da4db# | grep Location
echo "
Dropbox will notify of changes on the terms"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b5debc612b306fec# | grep Location
echo "
Dropbox can cancel your account without notice but they&#39;ll try to avoid it"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/fe677416342f38df# | grep Location
echo "
Dropbox allows you to leave the service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4307a9e1d2f5718c# | grep Location
echo "
Dropbox will not be liable for any loss or corruption of your stuff"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f1f3648e0269ce05# | grep Location
echo "
Dropbox allows you to retain full control of your copyright"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/97af3e6437aa5e94# | grep Location
echo "
Dropbox can remove content from your account"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5a6a0927912b3dea# | grep Location
echo "
Important: what&#39;s next for the coming weeks?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a6550fbc8d430b8c# | grep Location
echo "
Amazon requires claims to be resolved by binding arbitration rather than in court"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4c6c0528319a0fb6# | grep Location
echo "
Amazon doesn&#39;t require personal information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/cf3d8d200c88cb63# | grep Location
echo "
Amazon allows you to leave the service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6c53cdff6aea4397# | grep Location
echo "
Amazon allows ad services cookies and group filtering on personal information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/637e9b8d3bcc38bb# | grep Location
echo "
Amazon shares personal information with third parties"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1501b627be7564a9# | grep Location
echo "
Amazon uses cookies to identify users in third party websites"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/139f1a3edccfde39# | grep Location
echo "
Amazon requires cookies to function"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8393ec3f44c3a161# | grep Location
echo "
Amazon tracks you"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/15fc79f58bd21766# | grep Location
echo "
Amazon can change ToS any time, without notice"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3f4e75e713e0def8# | grep Location
echo "
Amazon Choice of law: Federal Arbitration Act, federal laws and state of Washington"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3c238b007259ae89# | grep Location
echo "
Amazon has a good refund policy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0c8fbe3a7a60e96c# | grep Location
echo "
You indemnify Amazon from any claim related to your content"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f32fe6304eb9c59b# | grep Location
echo "
Amazon holds unlimited copyright license on your content"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7e6c099d26189015# | grep Location
echo "
Amazon can cancel your account and remove content at any time."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9b0cb3d2377e1219# | grep Location
echo "
Unsubscribing LinkedIn + general thoughts about unsubcribing"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/952190f2d0fb54e1# | grep Location
echo "
Law enforcement/Courts and legal provisions and transparency of requests"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/fe7dc3ef09865306# | grep Location
echo "
Reddit is open source"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/94a04a5d42d89e10# | grep Location
echo "
IFTTT claims property for user feedback/comment"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7dd7d8103f90ae36# | grep Location
echo "
You indemnify Reddit from any claim related to your content"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/77a3aa8df9a00960# | grep Location
echo "
Reddit shares data with third parties"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5eeede684221ee1d# | grep Location
echo "
Reddit requires third party cookies"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/74c2f0c493a1f833# | grep Location
echo "
Reddit allows users to leave the service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b19fc74d6d389975# | grep Location
echo "
Reddit choice of law: State of New York"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/cd649fc1d835820c# | grep Location
echo "
Reddit holds unlimited copyright license on your content"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f659175aa46fa18b# | grep Location
echo "
Reddit doesn&#39;t allow modifications to its design"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4f45ef06890f98a7# | grep Location
echo "
Reddit doesn&#39;t allow to transfer accounts"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b570f41bb40ae0ed# | grep Location
echo "
Reddit doesn&#39;t require cookies to work"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f5070662be511366# | grep Location
echo "
IFTTT Jurisdiction in California"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6a2dd660f9d0bf7f# | grep Location
echo "
Amazon"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/dc8dcec785f86e75# | grep Location
echo "
HTTP request header for client-side EULAs."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d493c0d42b916eb7# | grep Location
echo "
IFTTT doesn&#39;t allow users to terminate their accounts, only discontinue usage"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/25336a1d3417a2c0# | grep Location
echo "
Reddit may share information to advertisers"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/524cf058bfa4673b# | grep Location
echo "
Reddit requires little personal information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2998c1e72194e596# | grep Location
echo "
IFTTT Doesn&#39;t ask for a real name"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0308d0e4835f77d6# | grep Location
echo "
ToSdr animation idea"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/67f3dc80f57f2e99# | grep Location
echo "
Reddit doesn&#39;t notify of ToS updates and assumes acceptance"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1329f77529a18d14# | grep Location
echo "
To use IFTTT you must be an individual and 18 years old"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e39a7a732fb407d0# | grep Location
echo "
Etsy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0ac599021e713f69# | grep Location
echo "
Privacy Score"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d208020078b7eb0c# | grep Location
echo "
IFTTT may change ToU without notification and assumes acceptance"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7cf799a368d8f8e1# | grep Location
echo "
Deleting your account on Spotify"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f098c03425929bc2# | grep Location
echo "
Next steps for contributors?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/09e0443a2347244d# | grep Location
echo "
interparcel.com T&amp;C&#39;s"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/02706f67707f8176# | grep Location
echo "
Facebook gone from ToS;DR?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1c8aed6ba23d4603# | grep Location
echo "
press links"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/78fc2c02a2932540# | grep Location
echo "
input from IrDial blog"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/79868b9263b92ad6# | grep Location
echo "
Thank you !!!!"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f78c86e368250b83# | grep Location
echo "
Nivsu wants to join in"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a41f23ee8e356cfc# | grep Location
echo "
Legal expertise?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/cd77ab00e7c69001# | grep Location
echo "
F-List: A brief overview of most of the terms."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/60a1d43f005ae576# | grep Location
echo "
TwitVid does not allow to delete account/profile + No way to opt-out from service e-mails"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4fa23735abc17aef# | grep Location
echo "
Some help for french translation ?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8688101a9a9597d2# | grep Location
echo "
Go Voyages :"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2e93e50b65d22f7e# | grep Location
echo "
TOS;DR suggestion"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2094aa05f810d306# | grep Location
echo "
Steam - Multiple software licenses are bundled"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ba376e6901295859# | grep Location
echo "
Apple iLife : location information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/692e86d2350a35c8# | grep Location
echo "
twitter... no thumbs down on &quot;Unlimited copyright license on your content&quot;"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/456cda28f06b4b02# | grep Location
echo "
paypal"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/124efdc2ebf9200d# | grep Location
echo "
Waze: improving but still..."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7c793b53a9f1eedd# | grep Location
echo "
Mobility Trip"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/21934121b55546db# | grep Location
echo "
Unofficial ToS;DR Facebook Page"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e7ce1cf2b2b5bf6f# | grep Location
echo "
(bad) Skype can cancel your account if they &quot;suspect you&quot;"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0a02b2725f13fe51# | grep Location
echo "
LiveJournal terms of service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/40a397ec97e2dc98# | grep Location
echo "
(good) Fairpoint sends printed update on ToS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/652e1f20888d73c6# | grep Location
echo "
(mistake ?) Skype : there is right to leave the service."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c04d983d41ce78ba# | grep Location
echo "
(bad) Skype has third party cookies"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3fd16bc7466887b2# | grep Location
echo "
Mandatory automatic subscription renewal without reminders - experteer.co.uk"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3b6a22f4bc298e1b# | grep Location
echo "
Burning Man reasonable photo policy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/20d5bc7adb876f3f# | grep Location
echo "
pre-generated html for the website"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c398d5a07c202110# | grep Location
echo "
Netflix - Class action waiver"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3da7c0f8f72218f8# | grep Location
echo "
WhatsApp ToS are hidden and unease"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/29e47831ba18b160# | grep Location
echo "
WhatApp has no subscribing for its ToS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8f6522f6b123d0b6# | grep Location
echo "
WhatsApp has no personalized advertisement"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/01ed1bc34c15ddec# | grep Location
echo "
Google &quot;Google can use your content for all their existing and future services&quot; is a good point."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0c18a0ce5e6362a5# | grep Location
echo "
WhatsApp has minimal data census"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e3a6c1bb9bfd8381# | grep Location
echo "
Bitcasa"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/236c8aa5a90f9ebd# | grep Location
echo "
Facebook"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b5d377e35dd7f5f9# | grep Location
echo "
Applits, lose all the rights to your idea"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/705b3e82949a0310# | grep Location
echo "
(good) We can ask for information about the license in Quake Live"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b686c20ad84e6ca8# | grep Location
echo "
(good) Quake Live has transparency on law enforcement requests"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1b0238e45f2ff2e1# | grep Location
echo "
API agreements"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e668324e0810ef4d# | grep Location
echo "
The possibility to add ToS to the Website"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/fc58bc74eeed321b# | grep Location
echo "
Terms for the group"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7fd8d8078131382d# | grep Location
echo "
Fotocommunity rating"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/15a931cd3a51a7a3# | grep Location
echo "
Wikimedia: Time Limit on Legal Action"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7a786dda502b05ac# | grep Location
echo "
Wikimedia: Exclusive legal venue -- San Francisco Cty, CA"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a436ec808dc50af9# | grep Location
echo "
Wikimedia: Promise to inform about data requests"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f665f5266f28895d# | grep Location
echo "
Wikimedia: 30-60 day notice before substantive TOS change, with public comment"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0738f331a3ee2a89# | grep Location
echo "
Wikipedia: User content perpetually licensed to Wikimedia under open content licenses"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f26b8285b9344be0# | grep Location
echo "
The tragedy of hotel Wi-Fi ToS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7b615c4a90c32884# | grep Location
echo "
CGU Looki France ( Game free to play, but not really free...) the best free swindle of the year !"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0a92206c956e3bd3# | grep Location
echo "
Deviant Art"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e5dd1ff27915263b# | grep Location
echo "
(good point) WhatsApp does not store content of messages"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9233108786c6ce81# | grep Location
echo "
Sites that prohibit MP3 downloads"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/60a7a730f6132090# | grep Location
echo "
New service: Medium"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9fdf271f33bd4c0c# | grep Location
echo "
World of Warcraft/Battle.net ToS Errors"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c7f1e615a9e0c3d0# | grep Location
echo "
Jobs at Google Mountain View"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4137939a79e3267f# | grep Location
echo "
Translated terms of service to other languages."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/16ed838492e8b087# | grep Location
echo "
Mojang TOS [re: Minecraft]"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/867c2f1cbc5820ee# | grep Location
echo "
Pinterest Review"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/99cd340b0b7d3102# | grep Location
echo "
Apple TOS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/dc359dc1aebc3ebd# | grep Location
echo "
Regarding Twitter"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/243565127d6a26bb# | grep Location
echo "
Last.FM - Am I doing it right?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d3a3e06c0084f1ef# | grep Location
echo "
Spotify"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1cd0aa594377c83f# | grep Location
echo "
an APP"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5da41406f109c9bb# | grep Location
echo "
icloud TOS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/57490da871b1d6e1# | grep Location
echo "
Mojang/Minecraft ToS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/dca0362229c8040a# | grep Location
echo "
Wordfeud"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d6d9ccec857e06fe# | grep Location
echo "
TOS in Thailand, what a joke!"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/23c8645892d9c344# | grep Location
echo "
Dropbox removes Copyright intellectual property after a claim"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/aec246b28d3428b6# | grep Location
echo "
The good, bad and neutral - Instagram.com"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6be7c5f68d3dc827# | grep Location
echo "
Reddit can allows SP to delete content without notice"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/93ff2746223142c6# | grep Location
echo "
Minecraft&#39;s usage policy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1b419f0cc6813b9d# | grep Location
echo "
how can i use this service to write TOS for my own app?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/88721647cf65072d# | grep Location
echo "
Steam agreement"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5547eb7573697f07# | grep Location
echo "
Concerning your awesome website, I have an idea that would make it infinitely better!"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/df6070f84939e740# | grep Location
echo "
Amazon&#39;s &quot;Conditions of Use&quot;"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/eecc098cbfc8a009# | grep Location
echo "
Potential confusion for Steam"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/13e9314b5332259c# | grep Location
echo "
deviantArt TOS: A long and complex bog of legalize and execuspeak, plus four or more other policies."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9d940cfbc2af5805# | grep Location
echo "
(title unknown)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/abbf365c4d9152cb# | grep Location
echo "
(good) Yahoo: you can terminate your account -- right to leave the service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c5e290395b305d5b# | grep Location
echo "
Yahoo asks for indemnification from users"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/088b22e8c33c6e4a# | grep Location
echo "
(good+bad) Yahoo copyright license is limited. The license ends when the user removes the content."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/584c2fe55d8cf73c# | grep Location
echo "
(bad) Yahoo requires real name or grounds for account termination."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/24d8ce3b4807597d# | grep Location
echo "
(bad) Yahoo can change the ToS without notification"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/45c3841061b38949# | grep Location
echo "
(good) Flickr lets you choose the copyright license"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2b533b563d56d553# | grep Location
echo "
(information) Flickr users are subject to Yahoo!&#39;s PP and ToS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/535d6a029c0d2f63# | grep Location
echo "
(bad) Flickr: pro accounts cannot be canceled"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/633f3fd7917591f6# | grep Location
echo "
(good) Flickr gives you a choice: with whom you share your photos"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b19e8c548c00fad1# | grep Location
echo "
Comparison between GitHub and Steam"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/117005e7d325d64b# | grep Location
echo "
tosdr.co-ment.com is &quot;Not Active&quot;"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3e9a1f744ef2839f# | grep Location
echo "
Flickr ToS &amp; PP"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ec853b2c15b15752# | grep Location
echo "
(copyright license) You License Freely Your Contributions (copyleft)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/45d7e2d21214551f# | grep Location
echo "
(readability, good) Wikipedia ToU are translated in 20 languages"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/df9e3e2a97babc5e# | grep Location
echo "
Wikipedia&#39;s Terms of Use were drafted collaboratively by the community"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/340fdbb8a993be81# | grep Location
echo "
Standardized list of minimum ToS data point topics"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b43332b61fe22e8f# | grep Location
echo "
timestamps and versions"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8ba2f2f24d5a988c# | grep Location
echo "
Steam - users defend and indemnify Valve"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/33e6db7b875221b2# | grep Location
echo "
BitBucket TOS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e8899a7e36f74600# | grep Location
echo "
(bad) Only VIP accounts will receive notice before potential termination"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/20f21ea592741adb# | grep Location
echo "
(bad) Wordpress.com ToS can change without notice, viewing a new agreement is the same as accepting"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/001fa8750c74fffb# | grep Location
echo "
Wikipedia ToU &amp; PP"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a431e7ca0a807f4e# | grep Location
echo "
Netflix ToU &amp; PP"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2f9a65d159fd94a6# | grep Location
echo "
Craigslist drops exclusive license to your posts"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/34ca7a51210169fc# | grep Location
echo "
Steam Subscriber Agreement &amp; Privacy Policy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ae1ca4a31ed751fb# | grep Location
echo "
Google Chrome now forces you to use Chrome Web Store as only choice"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1ce687584cd56fa8# | grep Location
echo "
delicious new terms 2. no right to leave the service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/cc3daccda2769303# | grep Location
echo "
(title unknown)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8272a5e06df73e63# | grep Location
echo "
Goodreads owns most of your content in perpetuity"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/73b245f786f8f3bc# | grep Location
echo "
eff tosback2"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6c223b59c8ccdc86# | grep Location
echo "
Please do assess Wikipedia"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0cb8d0dae9d47779# | grep Location
echo "
Salesforce/Chatter"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1acd01e5f44b76f8# | grep Location
echo "
Congratulations"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6fbe28b96ba56da3# | grep Location
echo "
Crashplan Rating?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7d4dde22dc0582cb# | grep Location
echo "
Gravatar: Takes copyright, can transfer copyright, can sublicense"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2a3e6dcaac49933e# | grep Location
echo "
Facebook give personal details to 3rd Party by default"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f93aa4f2bb2f4d3a# | grep Location
echo "
You will not provide any false personal information on Facebook"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6a1f6e9dde3c22dc# | grep Location
echo "
http://tos-dr.info/ doesn&#39;t work in Internet Explorer apparently?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ec3b4c0418e2b2ce# | grep Location
echo "
Chrome Browser Plugin"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/738d8251e10d2af1# | grep Location
echo "
Idea - in addition to classification letters"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3ac22250d376e5b3# | grep Location
echo "
Developers specific rating for Terms of Services and policy : focus on APIs"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/446b79470d2bdf85# | grep Location
echo "
Legal eagle."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7d74291b6d48a639# | grep Location
echo "
Idea - Privacy Watch website (tosdr@googlegroups.com)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/38980dc44b48047a# | grep Location
echo "
The user has to use at Xing his/her real name"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/fe17b5d3bece1936# | grep Location
echo "
The user can leave Xing without cause"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0cf90e7e3aa151cd# | grep Location
echo "
Xing value the data privacy of their users"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e927cd057c2cafca# | grep Location
echo "
Google Transparency Report"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d47fad1925c8b754# | grep Location
echo "
Twitter publishes &#39;Transparency Report&#39; on government requests and DMCA notices"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a0f779fbf6b46955# | grep Location
echo "
GitHub provides detailed information about their security policy and practices"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/daf221e25eec4e79# | grep Location
echo "
How GitHub deals with your data and legal requests or obligation"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5ec31c8ec58259b2# | grep Location
echo "
Github, in case of business transfer"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f0b0c4d993d7456e# | grep Location
echo "
(title unknown)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/832322024579646d# | grep Location
echo "
Github explains why hte information is used and collected"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ca687cb91fe3e750# | grep Location
echo "
GitHub choice of law (no jurisdiction)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9573cab9053498f2# | grep Location
echo "
GitHub doesn&#39;t ask for a copyright license"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/94e1bb5de522fb71# | grep Location
echo "
Github can suspend your service and delete your data any time for any reason"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/848e53a28fee0d59# | grep Location
echo "
GitHub wants you to defend and indemnify them"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1293cd9d85c15bfc# | grep Location
echo "
no pseudos allowed on GitHub"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/db38ea3a64b7142e# | grep Location
echo "
Github can change the terms without notice"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f5ea5797b6436fb7# | grep Location
echo "
Roadmap, your help and feedback is needed!"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/eb11a046929ba43f# | grep Location
echo "
soundcloud privacy: use and share of personal information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ddfddd54f09ad465# | grep Location
echo "
soundcloud privacy: information collected automatically"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c3c44cb46751bdd3# | grep Location
echo "
soundcloud privacy: pseudos allowed"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/167c2ef59e5cac61# | grep Location
echo "
soundcloud termination"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/82ad4b5bb976f2a2# | grep Location
echo "
soundcloud jurisdication and applicable law"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a6cd59a6938e5a63# | grep Location
echo "
soundcloud indemnification"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9ff0c29cec1c228d# | grep Location
echo "
soundcloud copyright license is one of best i have seen so far"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/fe023cc10dcf6763# | grep Location
echo "
soundcloud changes in terms: 6 weeks ultimatum"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/fada96c34dd43e87# | grep Location
echo "
readability is good on soundcloud terms of service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7e694aa2e5ca51c7# | grep Location
echo "
soundcloud community guidelines"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c6f3791aeff49776# | grep Location
echo "
Coming To Terms"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/af12e2bd89ae6e48# | grep Location
echo "
500px Store: moral rights waiver (on photographs)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a334b57ad347ed90# | grep Location
echo "
500px: waiver of legal action"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/dee888acbca3f07c# | grep Location
echo "
500px copyright license scope"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5fdf5252757b454b# | grep Location
echo "
500px isn&#39;t open to anyone"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/cbba6895844a4cdd# | grep Location
echo "
500px pseudonyms are allowed"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c763b26dd082956d# | grep Location
echo "
500px terms can change at any time"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b8f934ae693aff5c# | grep Location
echo "
Google notice of changes in the ToS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1d42ffe3021b3466# | grep Location
echo "
Google helps you stay secure and control some of your information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f39733ea1271ccb8# | grep Location
echo "
Targeted ad via facebook&#39;s cookies [similar to Google DoubleClick Ad Exchange]"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/bb1b2a21ab901723# | grep Location
echo "
Millions Will Flow to Privacy Groups Supporting Weak Facebook Settlement"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/dcf9331b6661c28b# | grep Location
echo "
Youluh, focusing on EULAs"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/62c75b619f3e1fa9# | grep Location
echo "
an article about google ToS &amp; Privacy Policy on BBC"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/af68dbc01c5dfd69# | grep Location
echo "
an opportunity to integrate tos-dr in the browser"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e7d0e6758beedc86# | grep Location
echo "
Facebook doesn&#39;t allow pseudonyms and asks users to point them out"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/80e4c4f79267bc29# | grep Location
echo "
ToS; Didn&#39;t Read &amp; Tosback 2 [need more legal participation from US]"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e405d3b389f7b785# | grep Location
echo "
Similar-ish project: tl;dr legal"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6c535efb188dbdee# | grep Location
echo "
Twitpic privacy policy"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0d2b5a5e6c01ce63# | grep Location
echo "
&quot;Deleted Images&quot; are not really deleted"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6faaf2a98f4d74cc# | grep Location
echo "
Question: can Twitpic reduce the prescription of legal action?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7427f1d5a307d53c# | grep Location
echo "
Twitpic choice of law clause and choice of jurisdiction: Delaware"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/57f4555c6ed32840# | grep Location
echo "
More madness from Twitpic: indemnification from claims related to user content"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8c5d41e16634c7b9# | grep Location
echo "
Twitpic takes credit for user pictures"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/e1987c831f48c837# | grep Location
echo "
Fwd: Lightning Talks"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0802f0b8ff2ff912# | grep Location
echo "
Adding CC-BY-SA license information to .json files"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4ddb9c504f9f86df# | grep Location
echo "
Fwd: US-Canada statement of privacy principles"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/a8e5a66cbb367122# | grep Location
echo "
Twitpic copyright license also granted to their &quot;partners&quot;"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/46de33b8f771deab# | grep Location
echo "
Google: changes in ToS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9a73056011930ef7# | grep Location
echo "
Google: choice of law and choice of jurisdiction clause"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/25c1a0f533d9ed5d# | grep Location
echo "
Google: copyright scope of the general ToS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/954f908455cc39c5# | grep Location
echo "
a good article with real life examples with broad copyright licenses from Twitpic, twitter"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d390df3a4cf59217# | grep Location
echo "
AT&amp;T, Verizon, Sprint, T-Mobile: sharing your location data, but not with you"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/89fedb6018eabfa8# | grep Location
echo "
should we have a twitter button on the website?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/af917432e74c6cfe# | grep Location
echo "
tossos"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7b97f54f47902c4f# | grep Location
echo "
is using webserver logs ok?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/091909be653dc24e# | grep Location
echo "
let&#39;s crowd-read (in German) the mitfahrgelegenheit ToS update"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6aee07d9723296dd# | grep Location
echo "
personal data and business transfers twitter, google, delicious and al."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f39a361d8d464184# | grep Location
echo "
Fwd: [Freedombox-discuss] UUID tracked"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/54f8fdd6ce60f567# | grep Location
echo "
Delicious class D"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ae9cda3696d6dc01# | grep Location
echo "
Instagram copyright license: no transfer, no sublicense"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c32f50705e734082# | grep Location
echo "
Gravatar: no right to leave the service?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/4fdf286eb26c8c90# | grep Location
echo "
Facebook&#39;s tracking &quot;Like&quot; buttons, to become even more pervasive with OpenGraph API"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/39597b55c568dfce# | grep Location
echo "
Sonic.net (ISP) deletes logs after 2 weeks"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9ee69256bf5895a0# | grep Location
echo "
Twitter&#39;s practice to notify changes in ToS [Fwd: [IFOSSLR Ed-Com] Updates to Twitter and Our Policies]"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/eb316e677ed9a657# | grep Location
echo "
Delicious previous terms"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d7f742ddd44b28d4# | grep Location
echo "
(title unknown)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1b8891e4a1fb595c# | grep Location
echo "
Facebook educate their users about how to be safe"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/45df4e845ea37818# | grep Location
echo "
OwnCube"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1dcbf8418e563aea# | grep Location
echo "
reddit.com"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9f722e5e46c33e55# | grep Location
echo "
Newsblur allows import &amp; export, is open source"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/0d18f84ae0db9cff# | grep Location
echo "
delicious new terms 6. Personal information will be sold in case of business transfer"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9491ac8a4092109f# | grep Location
echo "
delicious new terms 5. third party services get access to personal information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/467f0cf8a40e70d5# | grep Location
echo "
delicious new terms 4. cookies will be used for targeted ad!"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6973880dbcdebd81# | grep Location
echo "
delicious new terms 3. your right to use the service only for personal and non commercial purposes"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/d282991bfa3f66ed# | grep Location
echo "
delicious new terms 2. no right to leave the service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/2dbc29ba4991b608# | grep Location
echo "
delicious new terms 1. copyright license"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b7e20da04e9f1fdf# | grep Location
echo "
Fwd: US Congressmen send letter on Do Not Track to W3C"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/73eb1bd00c411e14# | grep Location
echo "
SeenThis: class A ?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f13d93a192498582# | grep Location
echo "
SeenThis allows you to export your data in XML"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/20fb5afc6d864c99# | grep Location
echo "
Facebook tracks non-users, creates shadow-profiles"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f2c20ce8589ff891# | grep Location
echo "
Diaspora Pod Ratings"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/29eb5db082fdc567# | grep Location
echo "
first progress on http://tos-dr.info/"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/799d521af954d4d8# | grep Location
echo "
List of services providing archives of their ToS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/75a98e59315a868d# | grep Location
echo "
Widget Data is kept a maximum of 10 days (and opt-out)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5fafc6c720525671# | grep Location
echo "
Twitter does not requrie cookies"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/391eef916df89a6e# | grep Location
echo "
Your copyright license to Twitter does not end when you deactive your accont"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/7b417871abda2784# | grep Location
echo "
Twitter copyright license: very broad scope and 3rd parties"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b665df40818f4efb# | grep Location
echo "
Fwd: criteria to (not) add"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/6af150299dc363a9# | grep Location
echo "
Article: What Facebook knows (data mining, etc;)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/8ac0847712ffb238# | grep Location
echo "
Mozilla&#39;s Privacy Icons"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9b5135bf3eee211b# | grep Location
echo "
Google keeps your Searches forever"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c824b3751fe0396e# | grep Location
echo "
Facebook automatically shares your information"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/b3df14474271e99e# | grep Location
echo "
list of websites that don&#39;t store your primary nor your secondary data"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/aa7e8d1c831da6c0# | grep Location
echo "
identi.ca and joindiaspora.com have a federated architecture"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/ec402b1438bb7da1# | grep Location
echo "
DuckDuckGo doesn&#39;t track you"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/838456880aecd74e# | grep Location
echo "
Facebook &quot;help&quot; page about the tracking &quot;Like&quot; buttons (aka &quot;social plugins&quot;)"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f539b78306279551# | grep Location
echo "
A clause in the TOS may contradict law in a country and therefore be void."
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/14fa96f653df7a09# | grep Location
echo "
Twitter notifies users by a tweet or by email when ToS are changed"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/f81e223bef711ef8# | grep Location
echo "
Facebook sollicited public feedback before launching new ToS"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/5539567ee6df89be# | grep Location
echo "
500px terms of service"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/c1816a72f3a7ed76# | grep Location
echo "
Flattr could do better to handle age limit"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/fd9350f49d3b9ed2# | grep Location
echo "
Flattr fights hard to make their ToS consumer-rights friendly"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/1fd705db2fbcb43d# | grep Location
echo "
Facebook UI induces oversharing"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/9e69a3c263cdacf5# | grep Location
echo "
EFF publishes report about companies practices regarding handing over data to governments"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/3b58e89763c40913# | grep Location
echo "
What&#39;s the right balance in a copyright license for publishing over &quot;social networks&quot;?"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/922ceb37ba9bd429# | grep Location
echo "
Google - wikipedia page summarizing criticism of Google"
curl --silent --user-agent "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31" -i http://groups.google.com/group/tosdr/browse_thread/thread/518d187f6fa1065d# | grep Location
